"""Optional TorchScript execution of exactly the registered power graph.

No approximation, changed precision, external compiler, or additional package.
The eager path remains the diagnostic reference and state_dict remains unchanged.
"""
import time
import warnings
import torch

class _Field(torch.nn.Module):
    def __init__(self,model):super().__init__();self.model=model
    def forward(self,x):return self.model.field(x,create_graph=True)

def trace_field(model):
    if getattr(model,'_compiled_field',None) is not None:return
    started=time.monotonic()
    example=torch.zeros(2,model.dim,dtype=model.mass.dtype,device=model.mass.device)
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore',category=torch.jit.TracerWarning)
        traced=torch.jit.trace(_Field(model),example,check_trace=False,strict=False)
    original=dict(model.named_parameters())
    for name,p in traced.named_parameters():
        key=name.removeprefix('model.')
        if key not in original or p.data_ptr()!=original[key].data_ptr():
            raise RuntimeError('Traced parameters do not alias the optimized model')
    # Do not register a recursive child module or serialize the execution cache.
    object.__setattr__(model,'_compiled_field',traced)
    model.trace_build_seconds=time.monotonic()-started
