import math,time
import torch
from torch.utils.checkpoint import checkpoint

def rk4(model,z,dt,training=True):
    if dt<=0:raise ValueError('dt must be positive')
    fn=lambda x:model.field(x,create_graph=training)
    a=fn(z);b=fn(z+dt*a/2);c=fn(z+dt*b/2);d=fn(z+dt*c)
    out=z+dt*(a+2*b+2*c+d)/6
    if not torch.isfinite(out).all():raise FloatingPointError('Nonfinite ODE state; not a physical instability label')
    return out

def rollout(model,z0,steps,sample_dt=.01,max_step=.01,training=True):
    sub=max(1,int(math.ceil(sample_dt/max_step-1e-10)));dt=sample_dt/sub
    z=z0;out=[z]
    width=max(1,int(getattr(model,'checkpoint_steps',0))) if training else 1
    def chunk(start,count):
        vals=[];zz=start
        for _ in range(count):
            if time.time()>=getattr(model,'save_deadline',float('inf')):
                raise TimeoutError('Save deadline reached during integration/recomputation')
            for __ in range(sub):zz=rk4(model,zz,dt,training)
            vals.append(zz)
        return torch.stack(vals,dim=1)
    for start in range(0,steps,width):
        if time.time()>=getattr(model,'save_deadline',float('inf')):
            raise TimeoutError('Save deadline reached inside ODE integration')
        count=min(width,steps-start)
        if training and getattr(model,'checkpoint_steps',0)>0:
            part=checkpoint(lambda zz,count=count:chunk(zz,count),z,use_reentrant=False)
        else:part=chunk(z,count)
        out.extend(part.unbind(dim=1));z=part[:,-1]
    return torch.stack(out,dim=1)
