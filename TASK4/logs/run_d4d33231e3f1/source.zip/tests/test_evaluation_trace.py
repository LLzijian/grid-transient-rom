"""Synthetic evaluation-executor parity, with no real assets or metrics."""
import copy
import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np
import pytest
import torch

from task4.accelerate import trace_field
from task4.dynamics import PowerGraph, UnstructuredGraph
from task4.evaluation import forecast_batch
from task4.paths import ROOT
from task4.synthetic import fixture


@pytest.fixture(scope='module', params=('N', 'S', 'U'))
def graph_pair(request):
    torch.manual_seed(1287)
    if request.param == 'S':
        # Reuse the existing complete PolynomialFunction synthetic fixture;
        # importing its module does not execute any of that module's tests.
        spec = importlib.util.spec_from_file_location('trace_symbolic_fixture', ROOT / 'tests/test_symbolic_runtime.py')
        helpers = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helpers)
        eager, _, _ = helpers.polynomial_model(n=3, rank=2, hidden=8)
    else:
        _, physics = fixture(n=3, events=1, steps=12)
        cls = PowerGraph if request.param == 'N' else UnstructuredGraph
        eager = cls(physics, [.2, .3, .1], rank=2, hidden=8)
    eager.eval()
    traced = copy.deepcopy(eager)
    before = {key: value.detach().clone() for key, value in traced.state_dict().items()}
    assert eager.reuse_origin_terms is traced.reuse_origin_terms is False
    trace_field(traced)
    assert not traced._compiled_uses_origins
    assert set(before) == set(traced.state_dict())
    for key, value in traced.state_dict().items():
        torch.testing.assert_close(value, before[key], rtol=0, atol=0)
    return eager, traced


def compare_forecasts(eager, traced):
    for key in ('states', 'physical', 'substep_states', 'substep_physical'):
        np.testing.assert_allclose(eager[key], traced[key], rtol=2e-10, atol=2e-12, equal_nan=True, err_msg=key)
    for key in ('state_finite', 'substep_state_finite'):
        np.testing.assert_array_equal(eager[key], traced[key], err_msg=key)
    assert eager['failures'] == traced['failures']
    assert eager['substeps_per_output'] == traced['substeps_per_output']
    assert eager['actual_step_s'] == traced['actual_step_s']


@pytest.mark.parametrize('batch', (1, 8))
@pytest.mark.parametrize('step', (.0025, .005))
def test_frozen_rk4_eager_trace_all_states_and_physical_paths(graph_pair, batch, step):
    eager, traced = graph_pair
    z0 = torch.as_tensor(np.random.default_rng(983 + batch).normal(0., .025, (batch, eager.dim)), dtype=torch.float64)
    original = z0.clone()
    first = forecast_batch(eager, z0, steps=4, max_step=step)
    second = forecast_batch(traced, z0, steps=4, max_step=step)
    compare_forecasts(first, second)
    torch.testing.assert_close(z0, original, rtol=0, atol=0)
    assert first['failures'] == [None] * batch
    assert first['substep_state_finite'].all()
    assert first['states'].shape == (batch, 5, eager.dim)


@pytest.mark.parametrize('batch', (1, 8))
@pytest.mark.parametrize('step', (.0025, .005))
def test_initial_latent_nan_keeps_identical_first_failure_and_finite_neighbors(graph_pair, batch, step):
    eager, traced = graph_pair
    z0 = torch.zeros(batch, eager.dim, dtype=torch.float64)
    z0[0, -1] = float('nan')  # Physical coordinates are all finite.
    first = forecast_batch(eager, z0, steps=3, max_step=step)
    second = forecast_batch(traced, z0, steps=3, max_step=step)
    compare_forecasts(first, second)
    assert first['failures'][0]['stage'] == 'initial_state'
    assert first['failures'][0]['first_bad_substep'] == 0
    assert not first['state_finite'][0].any()
    assert np.isnan(first['states'][0]).all()
    if batch > 1:
        assert first['substep_state_finite'][1:].all()
        assert first['failures'][1:] == [None] * (batch - 1)


class LatentFailureClock(torch.nn.Module):
    """Synthetic wrapper: keep the N/S/U field, add a tensor-only hidden trap.

    The penultimate q is a clock and the last q is a fixed event marker. Only
    the marked event's latent derivative becomes NaN after 11ms; physical
    derivatives remain finite. This is not a proposed scientific model.
    """
    def __init__(self, graph):
        super().__init__()
        self.graph = graph
        self.n, self.dim, self.mass = graph.n, graph.dim, graph.mass
        self.reuse_origin_terms = False

    def physical(self, state):
        return self.graph.physical(state)

    def field(self, state, create_graph=True):
        compiled = getattr(self, '_compiled_field', None)
        if compiled is not None:
            with torch.set_grad_enabled(create_graph):
                return compiled(state)
        with torch.set_grad_enabled(create_graph):
            result = self.graph.field(state, create_graph=create_graph).clone()
            result[:, -2] = 1.
            bad = (state[:, -2] > .011) & (state[:, -1] > .5)
            result[:, -1] = torch.where(bad, torch.full_like(state[:, -1], float('nan')), torch.zeros_like(state[:, -1]))
        return result if create_graph else result.detach()


@pytest.fixture(scope='module')
def clock_pair(graph_pair):
    eager = LatentFailureClock(copy.deepcopy(graph_pair[0]))
    traced = copy.deepcopy(eager)
    trace_field(traced)
    assert not traced._compiled_uses_origins
    return eager, traced


@pytest.mark.parametrize('batch', (1, 8))
@pytest.mark.parametrize('step', (.0025, .005))
def test_late_latent_derivative_failure_and_batch_shrinking_are_identical(clock_pair, batch, step):
    eager, traced = clock_pair
    z0 = torch.zeros(batch, eager.dim, dtype=torch.float64)
    z0[0, -1] = 1.
    first = forecast_batch(eager, z0, steps=4, max_step=step)
    second = forecast_batch(traced, z0, steps=4, max_step=step)
    compare_forecasts(first, second)
    failed = first['failures'][0]
    assert failed['stage'] == 'k2_field'
    assert failed['first_missing_output_index'] == 2
    assert failed['first_bad_substep'] == (5 if step == .0025 else 3)
    assert first['state_finite'][0, :2].all() and not first['state_finite'][0, 2:].any()
    assert np.isfinite(first['states'][0, :2]).all() and np.isnan(first['states'][0, 2:]).all()
    if batch > 1:
        assert first['substep_state_finite'][1:].all()
        assert first['failures'][1:] == [None] * (batch - 1)


@pytest.fixture
def cli_script(monkeypatch):
    monkeypatch.syspath_prepend(str(ROOT / 'scripts'))
    spec = importlib.util.spec_from_file_location('evaluation_trace_cli', ROOT / 'scripts/evaluate.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_m3_trace_is_rejected_before_source_reads(cli_script, monkeypatch):
    monkeypatch.setattr(cli_script, 'check_authorized', lambda synthetic: None)
    monkeypatch.setattr(cli_script, 'read_json', lambda path: pytest.fail('M3 trace must reject before source reads'))
    monkeypatch.setattr(cli_script, 'trace_field', lambda model: pytest.fail('Fixed M3 must not trace'))
    monkeypatch.setattr(sys, 'argv', ['evaluate.py', '--baseline-m3', '--trace-field', '--output', 'unused.json'])
    with pytest.raises(ValueError, match='fixed M3 uses the eager'):
        cli_script.main()


@pytest.mark.parametrize('traced', (False, True))
def test_cli_option_preserves_identity_and_adds_execution_metadata(cli_script, monkeypatch, tmp_path, traced):
    checkpoint_path, output = tmp_path / 'constructed.txt', tmp_path / 'result.json'
    checkpoint_path.write_text('synthetic placeholder, not checkpoint data', encoding='utf-8')
    model = SimpleNamespace(reuse_origin_terms=False)
    metadata = {'synthetic': True, 'config': {'arm': 'P'}, 'kind': 'T4-N', 'step': 7}
    calls = []
    monkeypatch.setattr(cli_script, 'check_authorized', lambda synthetic: None)
    monkeypatch.setattr(cli_script.torch, 'set_num_threads', lambda value: None)
    monkeypatch.setattr(cli_script, 'project_path', lambda value: Path(value))
    monkeypatch.setattr(cli_script, 'digest', lambda path: 'constructed-source-hash')
    monkeypatch.setattr(cli_script, 'load_checkpoint', lambda path: (model, object(), object(), metadata))
    monkeypatch.setattr(cli_script, 'fixture', lambda: ([SimpleNamespace(id='constructed')], SimpleNamespace()))
    monkeypatch.setattr(cli_script, 'read_json', lambda path: pytest.fail('Synthetic CLI must not read source configuration'))
    def compile_stub(given):
        assert given is model and not given.reuse_origin_terms
        calls.append('trace')
        given.trace_build_seconds = .125
    def evaluate_stub(given, encoder, events, destination, **kwargs):
        assert given is model
        assert kwargs['fine_dt'] == .0025 and kwargs['coarse_dt'] == .005
        calls.append('evaluate')
        return {'summary': {}, 'model_identity': copy.deepcopy(given.evaluation_identity)}
    monkeypatch.setattr(cli_script, 'trace_field', compile_stub)
    monkeypatch.setattr(cli_script, 'evaluate', evaluate_stub)
    monkeypatch.setattr(cli_script, 'write_json', lambda path, result: Path(path).write_text(json.dumps(result, allow_nan=False), encoding='utf-8'))
    args = ['evaluate.py', '--synthetic', '--endpoint', 'P-N', '--checkpoint', str(checkpoint_path), '--output', str(output)]
    if traced:
        args.append('--trace-field')
    monkeypatch.setattr(sys, 'argv', args)
    cli_script.main()
    result = json.loads(output.read_text(encoding='utf-8'))
    assert calls == (['trace', 'evaluate'] if traced else ['evaluate'])
    assert result['model_identity'] == {'checkpoint': str(checkpoint_path), 'checkpoint_sha256': 'constructed-source-hash', 'kind': 'T4-N', 'step': 7}
    assert result['source_identity_unchanged']
    assert result['execution'] == {'field_executor': 'torchscript_trace' if traced else 'eager',
                                   'trace_field_requested': traced, 'trace_build_seconds': .125 if traced else 0.,
                                   'origin_terms_reused': False}
