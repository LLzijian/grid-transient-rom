import _bootstrap
import argparse
import json
import torch

from task4.paths import ROOT, read_json
from task4.data import load_events
from task4.training import load_checkpoint, check_authorized
from task4.evaluation import evaluate
from task4.synthetic import fixture


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', required=True)
    parser.add_argument('--split', choices=['train', 'validation'], default='validation')
    parser.add_argument('--output', required=True)
    parser.add_argument('--synthetic', action='store_true')
    parser.add_argument('--endpoint', choices=['P-N', 'P-S', 'A', 'U'])
    parser.add_argument('--batch-size', type=int, default=8)
    args = parser.parse_args()
    check_authorized(args.synthetic)
    if not args.synthetic and args.endpoint is None:
        raise ValueError('Real evaluation requires a registered --endpoint P-N/P-S/A/U')
    torch.set_num_threads(1)
    model, encoder, _, checkpoint = load_checkpoint(ROOT / args.checkpoint)
    if bool(checkpoint['synthetic']) != args.synthetic:
        raise ValueError('Synthetic/real checkpoint mode mismatch')
    if args.endpoint is not None:
        arm = checkpoint['config']['arm']
        expected_arm = 'P' if args.endpoint in ('P-N', 'P-S') else args.endpoint
        if arm != expected_arm:
            raise ValueError('Registered endpoint and checkpoint arm disagree')
        if args.endpoint == 'P-S' and checkpoint.get('kind') != 'T4-S':
            raise ValueError('P-S endpoint requires all seven explicit symbolic functions')
        if args.endpoint == 'P-N' and checkpoint.get('kind') != 'T4-N':
            raise ValueError('P-N endpoint requires an uncompressed T4-N checkpoint')
    if args.synthetic:
        events, physics = fixture()
        facts = {'split': 'synthetic', 'raw_count': len(events), 'eligible_count': len(events),
                 'excluded': [], 'test_payload_read': False}
    else:
        events, physics, facts = load_events(read_json(ROOT / 'configs/project.json'), args.split)
    result = evaluate(model, encoder, events, args.output,
                      horizons=(.05, .1) if args.synthetic else (1., 2., 5., 8.),
                      physics=physics, facts=facts, batch_size=args.batch_size, endpoint=args.endpoint)
    print(json.dumps(result['summary'], ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
