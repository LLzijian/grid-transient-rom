import _bootstrap
import argparse
import json
import torch

from task4.paths import ROOT, read_json
from task4.data import load_events, train_scales, digest
from task4.training import load_checkpoint, check_authorized
from task4.evaluation import evaluate, FrozenM3
from task4.synthetic import fixture


def main():
    parser = argparse.ArgumentParser()
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument('--checkpoint')
    source.add_argument('--baseline-m3', action='store_true')
    parser.add_argument('--split', choices=['train', 'validation'], default='validation')
    parser.add_argument('--output', required=True)
    parser.add_argument('--synthetic', action='store_true')
    parser.add_argument('--endpoint', choices=['P-N', 'P-S', 'A', 'U', 'M3'])
    parser.add_argument('--batch-size', type=int, default=8)
    parser.add_argument('--fine-dt', type=float, default=.0025)
    parser.add_argument('--coarse-dt', type=float, default=.005)
    args = parser.parse_args()
    check_authorized(args.synthetic)
    if args.baseline_m3:
        if args.endpoint not in (None, 'M3'):
            raise ValueError('--baseline-m3 can only use the fixed M3 endpoint')
        args.endpoint = 'M3'
    elif args.endpoint == 'M3':
        raise ValueError('M3 endpoint requires --baseline-m3')
    if not args.synthetic and args.endpoint is None:
        raise ValueError('Real evaluation requires a registered --endpoint P-N/P-S/A/U/M3')
    torch.set_num_threads(1)
    checkpoint = None
    if args.checkpoint:
        model, encoder, _, checkpoint = load_checkpoint(ROOT / args.checkpoint)
        if bool(checkpoint['synthetic']) != args.synthetic:
            raise ValueError('Synthetic/real checkpoint mode mismatch')
        model.evaluation_identity = {'checkpoint': str(ROOT / args.checkpoint),
                                     'checkpoint_sha256': digest(ROOT / args.checkpoint),
                                     'kind': checkpoint.get('kind'), 'step': checkpoint.get('step')}
    if args.endpoint is not None and checkpoint is not None:
        arm = checkpoint['config']['arm']
        expected_arm = 'P' if args.endpoint in ('P-N', 'P-S') else args.endpoint
        if arm != expected_arm:
            raise ValueError('Registered endpoint and checkpoint arm disagree')
        if args.endpoint == 'P-S' and checkpoint.get('kind') != 'T4-S':
            raise ValueError('P-S endpoint requires all seven explicit symbolic functions')
        if args.endpoint == 'P-N' and checkpoint.get('kind') != 'T4-N':
            raise ValueError('P-N endpoint requires an uncompressed T4-N checkpoint')
    if args.synthetic:
        events, physics = fixture()
        facts = {'split': 'synthetic', 'raw_count': len(events), 'eligible_count': len(events),
                 'excluded': [], 'test_payload_read': False}
    else:
        project = read_json(ROOT / 'configs/project.json')
        events, physics, facts = load_events(project, args.split)
    if args.baseline_m3:
        if args.synthetic or args.split == 'train':
            train_events, train_physics = events, physics
        else:
            train_events, train_physics, _ = load_events(project, 'train')
        scales = train_scales(train_events, train_physics)
        model, encoder = FrozenM3(physics, scales), None
        model.evaluation_identity = {'kind': 'fixed_M3', 'fitted_on_development': False,
                                     'scale_source': 'synthetic_fixture' if args.synthetic else 'TRAIN',
                                     'scale_event_ids': [event.id for event in train_events]}
    result = evaluate(model, encoder, events, args.output,
                      horizons=(.05, .1) if args.synthetic else (1., 2., 5., 8.),
                      physics=physics, facts=facts, batch_size=args.batch_size, endpoint=args.endpoint,
                      fine_dt=args.fine_dt, coarse_dt=args.coarse_dt)
    print(json.dumps(result['summary'], ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
